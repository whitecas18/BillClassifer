from SummPackage import ResolutionSummarizer


userInput = 0 


print('Welcome to the Government Bill Summarizer!...')

input('\n Press [Enter] to begin')

print('\nType END to end the program.')

while userInput != 'END':

    while userInput != 'END':
        userInput = input('\nEnter the START year for Bill Summaries in format yyyy [ex.2020] earliest year is 2000\n')
        
        if((len(userInput) == 4) and (userInput[0] == '2')):
            startYear = userInput
            break
        
        else:
            print('Invalid format ')
            
    
    while userInput != 'END':
        userInput = input('\nEnter the START month for Bill Summaries in format mm [ex. 03 for march]\n')
        
        if((len(userInput) == 2) and (int(userInput[0]) < 2) and (int(userInput[1]) <= 9)):
            startMonth = userInput
            break
        
        else:
            print('Invalid format')
            
            
    while userInput != 'END':
        userInput = input('\nEnter the START day for Bill Summaries in format dd [ex. 12]')
        
        if((len(userInput) == 2) and (int(userInput[0]) < 4) and (int(userInput[1]) <= 9)):
            startDay = userInput
            break
        
        else:
            print('Invalid format')
            
    
    while userInput != 'END':
        userInput = input('\nEnter the END year for Bill Summaries in format yyyy [ex.2020] earliest year is 2000. EARLIEST YEAR IS 2019')
        
        if((len(userInput) == 4) and (userInput[0] == '2')):
            endYear = userInput
            break
        
        else:
            print('Invalid format ')
            
    
    while userInput != 'END':
        userInput = input('\nEnter the END month for Bill Summaries in format mm [ex. 03 for march]')
        
        if((len(userInput) == 2) and (int(userInput[0]) < 2) and (int(userInput[1]) <= 9)):
            endMonth = userInput
            break
        
        else:
            print('Invalid format')
            
            
    while userInput != 'END':
        userInput = input('\nEnter the END day for Bill Summaries in format dd [ex. 12]')
        
        if((len(userInput) == 2) and (int(userInput[0]) < 4) and (int(userInput[1]) <= 9)):
            endDay = userInput
            break
        
        else:
            print('Invalid format')
            
    while userInput != 'END':
        userInput = input('\nEnter the max amount of Bills you want summarized')
        pageSize = userInput

        if userInput != 'END':
            ResolutionSummarizer.resolutionSumm(startYear,startMonth,startDay,endYear,endMonth,endDay,pageSize) 
            break       
           
    
   
    
