import json
import requests
from bs4 import BeautifulSoup


def getWebSiteText(startYear,startMonth, startDay,endYear,endMonth,endDay,pageSize,docNumber,type):
    
    newDict = {}
    
    url = 'https://api.govinfo.gov/collections/BILLS/'+startYear+'-'+startMonth+'-'+startDay+'T00%3A00%3A10Z/'+endYear+'-'+endMonth+'-'+endDay+'T24%3A18%3A10Z?offset=0&pageSize='+pageSize+'&docClass='+type+'&api_key=A5IBMbRtjbh9c7EYatrZmJNzFxkVgU8AGmtk8XbH'

    requestPackage = requests.get(url)

    j1 = json.loads(requestPackage.text)
    
    fileUrl = j1['packages'][docNumber]['packageLink'] + '?api_key=A5IBMbRtjbh9c7EYatrZmJNzFxkVgU8AGmtk8XbH'
     
    requestFile = requests.get(fileUrl)

    j2 = json.loads(requestFile.text)
    
    finalUrl = j2['download']['txtLink'] + '?api_key=A5IBMbRtjbh9c7EYatrZmJNzFxkVgU8AGmtk8XbH'

    requestFinal = requests.get(finalUrl)
    
    
    newDict['congress'] = j2['congress']
    newDict['session'] = j2['session']
    newDict['billNumber'] = j2['billNumber']
    newDict['date'] = j2['dateIssued']
    newDict['text'] = requestFinal.text\
    
    if 'members' in j2:
        newDict['sponsor'] = j2['members'][0]['memberName']
        
        if j2['members'][0]['party'] == 'R':
            newDict['sponsorAff'] = 'Republican'
        if j2['members'][0]['party'] == 'D':
            newDict['sponsorAff'] = 'Democrat'
        
        
    if  'shortTitle' in j2:
        newDict['title'] = j2['shortTitle'][0]['title']
    
    return newDict
    #return (requestFinal.text)

def getWebSiteDocCount(startYear,startMonth, startDay,endYear,endMonth,endDay,pageSize,type):
    url = 'https://api.govinfo.gov/collections/BILLS/'+startYear+'-'+startMonth+'-'+startDay+'T20%3A18%3A10Z/'+endYear+'-'+endMonth+'-'+endDay+'T20%3A18%3A10Z?offset=0&pageSize='+pageSize+'&docClass='+type+'&api_key=A5IBMbRtjbh9c7EYatrZmJNzFxkVgU8AGmtk8XbH'
    
    requestPackage = requests.get(url)

    j2 = json.loads(requestPackage.text)
    
    return (j2["count"])




    