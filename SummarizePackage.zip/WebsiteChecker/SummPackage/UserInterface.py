from SummPackage import ResolutionSummarizer
from datetime import date


def customSum():
    
    userInput = '-1'
    
    while userInput != 'END':
        
        userInput = input('\n\nType 1 or 2 for the following options:\n 1: Bills & Resolutions uploaded from 2019 \n 2: Bills & Resolutions uploaded from 2020')
        
        if(userInput == '1'):
            startYear = '2019'
            endYear = '2019'
            break
        elif(userInput == '2'):
            startYear = '2020'
            endYear = '2020'
        else:
            print('INVALID FORMAT, type option 1 or option 2 ')
            
    while userInput != 'END':
        userInput = input('\nEnter the START month for Bill Summaries in format mm [ex. 03 for march]\n')
        
        if((len(userInput) == 2) and (int(userInput[0]) < 2) and (int(userInput[1]) <= 9)):
            startMonth = userInput
            break
        else:
            print('Invalid format')
            
    while userInput != 'END':
        userInput = input('\nEnter the START day for Bill Summaries in format dd [ex. 12]')
        
        if((len(userInput) == 2) and (int(userInput[0]) < 4) and (int(userInput[1]) <= 9)):
            startDay = userInput
            break
        else:
            print('Invalid format')
              
    while userInput != 'END':
        userInput = input('\nEnter the END month for Bill Summaries in format mm [ex. 03 for march]')
        
        if((len(userInput) == 2) and (int(userInput[0]) < 2) and (int(userInput[1]) <= 9)):
            endMonth = userInput
            break
        else:
            print('Invalid format')
                
    while userInput != 'END':
        userInput = input('\nEnter the END day for Bill Summaries in format dd [ex. 12]')
        
        if((len(userInput) == 2) and (int(userInput[0]) < 4) and (int(userInput[1]) <= 9)):
            endDay = userInput
            break
        else:
            print('Invalid format')
            
    while userInput != 'END':
        userInput = input('\nEnter the max amount of Bills you want summarized')
        pageSize = userInput

        if userInput != 'END':
            ResolutionSummarizer.resolutionSumm(startYear,startMonth,startDay,endYear,endMonth,endDay,pageSize) 
            break       

def todaySum():
    
    rawDate = str(date.today()).split("-")
    
    todayYear = rawDate[0]
    todayMonth = rawDate[1]
    todayDay = rawDate[2]
    
    ResolutionSummarizer.resolutionSumm(todayYear,todayMonth,todayDay,todayYear,todayMonth,todayDay,'10')







print('Welcome to the Government Bill Summarizer!...')


userInput = '0'

while userInput != 'END':
    
    print('\n\nType END to end the program at any time\n\n')
    
    userInput = input('\nTYPE OPTION BELOW:\n1: Check and summarize todays Bills\n2: Check and summarize Bills from custom date')
    
    if(userInput == '1'):
        todaySum()
    elif(userInput == '2'):
        customSum()
        


















           
    
   
    
