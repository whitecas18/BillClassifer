from SummPackage import ResolutionSummarizer
from datetime import date
import datetime
from SummPackage.ResolutionSummarizer import jointResolutionSumm

def customSum(type):
    input = '-1'
    
    while input != 'END':
        
        input = input('\n\nType 1 or 2 for the following options:\n 1: Bills & Resolutions uploaded from 2019 \n 2: Bills & Resolutions uploaded from 2020')
        
        if(input == '1'):
            startYear = '2019'
            endYear = '2019'
            break
        elif(input == '2'):
            startYear = '2020'
            endYear = '2020'
            break
        else:
            print('\n- INVALID INPUT -\n  type option 1 or option 2 ')
            
    while input != 'END':
        input = input('\nEnter the START month for Bill Summaries in format mm [ex. 03 for march]\n')
        
        if((len(input) == 2) and (int(input[0]) < 2) and (int(input[1]) <= 9)):
            startMonth = input
            break
        else:
            print(' \n- INVALID INPUT -\n ')
            
    while input != 'END':
        input = input('\nEnter the START day for Bill Summaries in format dd [ex. 12]')
        
        if((len(input) == 2) and (int(input[0]) < 4) and (int(input[1]) <= 9)):
            startDay = input
            break
        else:
            print(' \n- INVALID INPUT -\n ')
              
    while input != 'END':
        input = input('\nEnter the END month for Bill Summaries in format mm [ex. 03 for march]')
        
        if((len(input) == 2) and (int(input[0]) < 2) and (int(input[1]) <= 9)):
            endMonth = input
            break
        else:
            print(' \n- INVALID INPUT -\n ')
                
    while input != 'END':
        input = input('\nEnter the END day for Bill Summaries in format dd [ex. 12]')
        
        if((len(input) == 2) and (int(input[0]) < 4) and (int(input[1]) <= 9)):
            endDay = input
            break
        else:
            print(' \n- INVALID INPUT -\n ')
            
    while input != 'END':
        input = input('\nEnter the max amount of Bills you want summarized')
        pageSize = input

        if input != 'END':
            ResolutionSummarizer.houseResolutionSumm(startYear,startMonth,startDay,endYear,endMonth,endDay,pageSize) 
            break       

def todaySum(type):
    
    rawDate = str(date.today()).split("-")
    
    todayYear = rawDate[0]
    todayMonth = rawDate[1]
    todayDay = rawDate[2]
    
    if type == '1':
        ResolutionSummarizer.houseResolutionSumm(todayYear,todayMonth,todayDay,todayYear,todayMonth,todayDay,'10')
    elif type == '2':
        ResolutionSummarizer.jointResolutionSumm(todayYear,todayMonth,todayDay,todayYear,todayMonth,todayDay,'10')

def weekSum(type):
    rawDate = str(date.today()).split("-")
    
    todayYear = rawDate[0]
    todayMonth = rawDate[1]
    todayDay = rawDate[2]
    
    begOfWeek = (datetime.datetime.today().weekday()) - int(todayDay)
    
    if type == '1':
        ResolutionSummarizer.houseResolutionSumm(todayYear,todayMonth,str(begOfWeek),todayYear,todayMonth,todayDay,'10')
    elif type == '2':
        ResolutionSummarizer.jointResolutionSumm(todayYear,todayMonth,str(begOfWeek),todayYear,todayMonth,todayDay,'10')   


def firstInput():
    userInput = '1';
    
    while True:
        userInput = input('\nTYPE SUMMARY OPTION BELOW:\n1:HOUSE BILLS\n2:JOINT RESOLUTIONS')
        
        if((userInput == '1') or (userInput == '2')):
            return str(userInput)
        elif(userInput == 'END'):
            input('\nExiting program...press enter to continue\n')
            print('\nbye..\n')
            quit()
        else:
            print(' \n- INVALID INPUT -\n ')

def secondInput(type):
    userInput = 0;
    
    while True:
        userInput = input('\nTYPE OPTION BELOW:\n1: Summarize todays Bills\n2: Summarize current week Bills\n3: Summarize custom date Bills')
        if(userInput == '1'):
            todaySum(type)
            break
        elif(userInput == '2'):
            weekSum(type)
            break
        elif(userInput == '3'):
            customSum(type)
            break
        elif(userInput == 'END'):
            input('\nExiting program...press enter to continue\n')
            print('\nbye..\n')
            quit()
        else:
            print(' \n- INVALID INPUT -\n ')

print('Welcome to the Government Bill Summarizer!...')

while True:
    
    print('\n\nType END to end the program at any time\n\n')
    
    type = firstInput()
    secondInput(type)
    
    
    

        


















           
    
   
    
