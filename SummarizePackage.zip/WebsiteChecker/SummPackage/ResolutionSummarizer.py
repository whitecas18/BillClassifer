import gensim
from gensim.summarization.summarizer import summarize
import requests
from SummPackage import WebsiteInfoGetter
from bs4 import BeautifulSoup

#summarizer parameters are the dates of the documents, first is the start date, second is the end date. Dates are in 4,2,2 format (yyyy,mm,dd,yyyy,mm,dd,).
def jointResolutionSumm(startYear,startMonth,startDay,endYear,endMonth,endDay,pageSize):
    
    numDocs = WebsiteInfoGetter.getWebSiteDocCount(startYear,startMonth,startDay,endYear,endMonth,endDay,pageSize,'hjres')
    
    print("\nThere are " + str(numDocs) + " joint resolutions to summarize from " + str(startMonth) + "-" + str(startDay) + "-" + str(startYear) + " to " + str(endMonth) + "-" + str(endDay) + "-" + str(endYear)+"\n")
    
    if(int(numDocs) < int(pageSize)):
        numSum = numDocs
    else:
        numSum = pageSize
         
    for docNumber in range(0 , (int(numSum) - 1)):
        
        newDict = WebsiteInfoGetter.getWebSiteText(startYear,startMonth,startDay,endYear,endMonth,endDay,pageSize,docNumber,'hjres')
        #remove list of unwanted words from text 
        removeWords = ['[document]','noscript','header','html','meta','head', 'input','script','<DOC>','``Article--','<all>',"\n"]
        #remove list of spacing
        removeSpaces = ["  ","   ","   ","    ","      "]
        
        text = newDict["text"]
       
        for word in removeWords:
            text.replace(word, "")
            
        for space in removeSpaces:
            text.replace(space, " ")
        
        #split text at Joint resolution where the text that needs to be summarized starts
        splitText = text.split("JOINT RESOLUTION")
        
        if(('title' in newDict) and ('sponsor' in newDict)):
            print("        Formal Title: " + newDict['title'] + "\n        " + newDict['congress'] + "th Congress" + "\n        Session: " + newDict['session'] + "\n        Resolution: " + newDict['billNumber'])
            print('        Date Issued: ' + newDict['date'] + "\n        Bill Sponsor and Pol. Party: " + newDict['sponsor'] + " " + newDict['sponsorAff'])
        elif( ('title' in newDict) and ('sponsor' not in newDict)):
            print("        Formal Title: " + newDict['title'] + "\n        " + newDict['congress'] + "th Congress" + "\n        Session: " + newDict['session'] + "\n        Resolution: " + newDict['billNumber'])
            print('        Date Issued: ' + newDict['date'] + "\n        No Sponsor")
        elif(('sponsor' in newDict) and ('title' not in newDict)):
            print('        No Formal Title:\n        ' + "\n        " + newDict['congress'] + "th Congress" + "\n        Session: " + newDict['session'] + "\n        Resolution: " + newDict['billNumber'])
            print('        Date Issued: ' + newDict['date'] + '\n        No Sponsor')
        else:       
            print('        No Formal Title:\n        ' + newDict['congress'] + "th Congress" + "\n        Session: " + newDict['session'] + "\n        Resolution: " + newDict['billNumber'])
            print('        Date Issued: ' + newDict['date'] + newDict['date'] + '\n        No Sponsor')
        # print summarization to console, always summarize from index 1.
        
        if 1 < len(splitText):
            print("\n" + (summarize(splitText[1], .75)) + "\n")
        else:
            print("\n" + (summarize(splitText[0], .75)) + "\n")

def houseResolutionSumm(startYear,startMonth,startDay,endYear,endMonth,endDay,pageSize):
        
    numDocs = WebsiteInfoGetter.getWebSiteDocCount(startYear,startMonth,startDay,endYear,endMonth,endDay,pageSize,'hr')
    
    print("\nThere are " + str(numDocs) + " joint resolutions to summarize from " + str(startMonth) + "-" + str(startDay) + "-" + str(startYear) + " to " + str(endMonth) + "-" + str(endDay) + "-" + str(endYear)+"\n")
    
    if(int(numDocs) < int(pageSize)):
        numSum = numDocs
    else:
        numSum = pageSize
         
    for docNumber in range(0 , (int(numSum) - 1)):
        
        newDict = WebsiteInfoGetter.getWebSiteText(startYear,startMonth,startDay,endYear,endMonth,endDay,pageSize,docNumber,'hr')
        #remove list of unwanted words from text 
        removeWords = ['[document]','noscript','header','html','meta','head', 'input','script','<DOC>','``Article--','<all>',"\n"]
        #remove list of spacing
        removeSpaces = ["  ","   ","   ","    ","      "]
        
        text = newDict["text"]
       
        for word in removeWords:
            text.replace(word, "")
            
        for space in removeSpaces:
            text.replace(space, " ")
        
        #split text at Joint resolution where the text that needs to be summarized starts
        splitText = text.split("IN THE HOUSE OF REPRESENTATIVES")
        
        if(('title' in newDict) and ('sponsor' in newDict)):
            print("        Formal Title: " + newDict['title'] + "\n        " + newDict['congress'] + "th Congress" + "\n        Session: " + newDict['session'] + "\n        Resolution: " + newDict['billNumber'])
            print('        Date Issued: ' + newDict['date'] + "\n        Bill Sponsor and Pol. Party: " + newDict['sponsor'] + " " + newDict['sponsorAff'])
        elif( ('title' in newDict) and ('sponsor' not in newDict)):
            print("        Formal Title: " + newDict['title'] + "\n        " + newDict['congress'] + "th Congress" + "\n        Session: " + newDict['session'] + "\n        Resolution: " + newDict['billNumber'])
            print('        Date Issued: ' + newDict['date'] + "\n        No Sponsor")
        elif(('sponsor' in newDict) and ('title' not in newDict)):
            print('        No Formal Title:\n        ' + "\n        " + newDict['congress'] + "th Congress" + "\n        Session: " + newDict['session'] + "\n        Resolution: " + newDict['billNumber'])
            print('        Date Issued: ' + newDict['date'] + '\n        No Sponsor')
        else:       
            print('        No Formal Title:\n        ' + newDict['congress'] + "th Congress" + "\n        Session: " + newDict['session'] + "\n        Resolution: " + newDict['billNumber'])
            print('        Date Issued: ' + newDict['date'] + newDict['date'] + '\n        No Sponsor')
        
        
        if 1 < len(splitText):
            if len(splitText[1]) > 30:
                if len(splitText[1]) > 80:
                    print("\n" + (summarize(splitText[1], .15)) + "\n")
                else:
                    print("\n" + (summarize(splitText[1], .35)) + "\n")
            else:
                print("\n" + (summarize(splitText[1], .75)) + "\n")
        else:
            if len(splitText[1]) > 30:
                if len(splitText[0]) > 60:
                    print("\n" + (summarize(splitText[0], .20)) + "\n")
                else:
                    print("\n" + (summarize(splitText[0], .35)) + "\n")
            else:
                print("\n" + (summarize(splitText[0], .75)) + "\n")


